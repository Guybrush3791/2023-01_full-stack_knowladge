<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>

        * {

            background: purple;
            color: white;
        }

        .green {

            color: green;
        }
        .red {

            color: red;
        }

        .bg-gray {

            background-color: grey;
        }
        .bg-green {

            background-color: green;
        }
    </style>
    <?php

        session_start();

        require_once __DIR__ . "/libs/helper.php";

        $lng = $_GET['length'] ?? -1;

        $minLetters = $_GET['minLetters'] ?? false;
        $maxLetters = $_GET['maxLetters'] ?? false;
        $numbers = $_GET['numbers'] ?? false;
        $symobols = $_GET['symobols'] ?? false;
        $dupplicate = $_GET['dupplicate'] ?? false;

        if ($lng > 0) {

            $pws = pwsGenrate($lng, $minLetters, $maxLetters, 
                                $numbers, $symobols, $dupplicate);
            $_SESSION['pws'] = $pws;
            header("Location: thankyou.php");
        }
    ?>
</head>
<body>
    
    <h1>Hello, World!</h1>
    <form>
        <label for="length">Length</label>
        <input type="number" name="length" 
            <?php
                if ($lng > 0) {
                    echo "value='" . $lng . "'";
                }
            ?>
        >
        <br>
        <input type="checkbox" name="minLetters">
        <label for="minLetters">Lettere minuscole</label>
        <br>
        <input type="checkbox" name="maxLetters">
        <label for="maxLetters">Lettere maiuscole</label>
        <br>
        <input type="checkbox" name="numbers">
        <label for="numbers">Numeri</label>
        <br>
        <input type="checkbox" name="symobols">
        <label for="symobols">Simboli</label>
        <br>
        <input type="checkbox" name="dupplicate">
        <label for="dupplicate">Caratteri dupplicati</label>
        <br>
        <input type="submit" value="GENERATE">
    </form>
</body>
</html>